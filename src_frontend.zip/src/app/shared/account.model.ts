export class Account {

    accountno: number;
    name: string;
    ifsc: number;
    amount: number;

    constructor()
    {
        this.accountno=1000000
        this.name=""
        this.ifsc=0
        this.amount=0
    }
}


