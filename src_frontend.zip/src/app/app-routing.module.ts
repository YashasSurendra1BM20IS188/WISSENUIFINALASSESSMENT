import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { WithdrawalComponent } from './withdrawal/withdrawal.component';
import { DepositComponent } from './deposit/deposit.component';
import { ChequedepositComponent } from './chequedeposit/chequedeposit.component';
import { BalanceenquiryComponent } from './balanceenquiry/balanceenquiry.component';

const routes: Routes = [
  {
    path:'',
    component:HomeComponent
  },
  {
    path:'registration',
    component:LoginComponent
  },
  {
    path:'withdrawal',
    component:WithdrawalComponent
  },
  {
    path:'balance enquiry',
    component:BalanceenquiryComponent
  },
  {
    path:'deposit',
    component:DepositComponent
  },
  {
    path:'chequedeposit',
    component:ChequedepositComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
