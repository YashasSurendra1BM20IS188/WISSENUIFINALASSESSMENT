import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BankserviceService } from '../services/bankservice.service';
import { Account } from '../shared/account.model';

@Component({
  selector: 'app-balanceenquiry',
  templateUrl: './balanceenquiry.component.html',
  styleUrls: ['./balanceenquiry.component.css']
})
export class BalanceenquiryComponent implements OnInit {
  balance:number;
  constructor(public bs: BankserviceService) { this.balance=0; }
 
  ngOnInit(): void {
  }
  onSubmit(form:NgForm)
  {
    console.log(form.value["accountNumber"])
    
      this.bs.getEmployee(1000000).subscribe((res)=>{
        var a=res as Account;
        this.balance = a.amount

      })
  }
}
