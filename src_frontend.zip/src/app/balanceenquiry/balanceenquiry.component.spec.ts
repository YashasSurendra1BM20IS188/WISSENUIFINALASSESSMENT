import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BalanceenquiryComponent } from './balanceenquiry.component';

describe('BalanceenquiryComponent', () => {
  let component: BalanceenquiryComponent;
  let fixture: ComponentFixture<BalanceenquiryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BalanceenquiryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BalanceenquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
