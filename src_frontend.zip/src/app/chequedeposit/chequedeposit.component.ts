import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BankserviceService } from '../services/bankservice.service';
import { Account } from '../shared/account.model';
@Component({
  selector: 'app-chequedeposit',
  templateUrl: './chequedeposit.component.html',
  styleUrls: ['./chequedeposit.component.css']
})
export class ChequedepositComponent implements OnInit {

  balance:number;
  constructor(public bs: BankserviceService) { this.balance=0; }
 
  ngOnInit(): void {
  }
  onSubmit(form:NgForm)
  {
    console.log(form.value)
      this.bs.getEmployee(form.value).subscribe((res)=>{
        var a=res as Account;
        this.balance = a.amount

      })
  }
}
