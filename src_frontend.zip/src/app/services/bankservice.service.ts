import { Injectable } from '@angular/core';
import { Account } from '../shared/account.model';
import { HttpClient } from '@angular/common/http';
import { WithdrawalComponent } from '../withdrawal/withdrawal.component';
@Injectable({
  providedIn: 'root'
})
export class BankserviceService {

  accounts: Account[];
  url:string = "http://localhost:8090/accounts"
  constructor(private http:HttpClient) { 
      this.accounts =[]
  }

  getEmployee(id : Number)
  {
     return this.http.get(this.url + "/" + id)
  }
  postemployee(account:Account)
  {
    return this.http.post(this.url,account)
  }
  withdraw(id:number , amount:number)
  {
    return this.http.put(this.url + "/withdrawal"+"?id="+id+"&amount="+amount,null)
  }
  deposit(id:number , amount:number)
  {
    return this.http.put(this.url + "/deposit"+"?id="+id+"&amount="+amount,null)

  }
  cheque(id1:number , amount:number,id2:number )
  {
    return this.http.put(this.url + "/chequedeposit"+"?id1="+id1+"&id2="+id2+"&amount="+amount,null)
  }
}
