package com.example.backend.Implementations;

import com.example.backend.Models.Emp;
import com.example.backend.Repositories.EmpRepository;
import com.example.backend.Services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImplementation implements EmployeeService {

    @Autowired
    private EmpRepository repo;

    @Override
    public Emp saveEmployee(Emp emp) {
        return repo.save(emp);
    }

    @Override
    public List<Emp> retrieveAllEmployees() {
        return repo.findAll();
    }

    @Override
    public Optional<Emp> getEmployeeDetails(int id) {
        return repo.findById(id);
    }

    @Override
    public Emp updateEmployeeDetails(Emp emp) {
        return repo.save(emp);
    }

    @Override
    public void deleteEmployeeRecord(int id) {
        repo.deleteById(id);
    }

    @Override
    public boolean employeeIdExists(int id) {
        return repo.existsById(id);
    }
}
