package com.example.backend.Payloads;

import com.example.backend.Models.Emp;
import lombok.*;
import org.springframework.http.HttpStatus;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmployeeObjectResponse {
    private String message;
    private boolean success;
    private HttpStatus status;
    private Emp employeeObject;
}
