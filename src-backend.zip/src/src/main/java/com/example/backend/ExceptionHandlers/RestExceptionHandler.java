package com.example.backend.ExceptionHandlers;

import com.example.backend.Exceptions.EmployeeAlreadyExistsException;
import com.example.backend.Exceptions.EmptyEmployeesListException;
import com.example.backend.Exceptions.NoEmployeeFoundException;
import com.example.backend.Payloads.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class RestExceptionHandler {

    @ExceptionHandler(NoEmployeeFoundException.class)
    public ResponseEntity<ErrorResponse> handleNoEmployeeFoundException(NoEmployeeFoundException exception) {
        String msg = exception.getMessage();
        ErrorResponse error = ErrorResponse.builder()
                .message(msg)
                .success(false)
                .status(HttpStatus.NOT_FOUND)
                .build();
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(EmptyEmployeesListException.class)
    public ResponseEntity<ErrorResponse> handleEmptyEmployeesListException(EmptyEmployeesListException exception) {
        String msg = exception.getMessage();
        ErrorResponse error = ErrorResponse.builder()
                .message(msg)
                .success(false)
                .status(HttpStatus.NO_CONTENT)
                .build();
        return new ResponseEntity<>(error, HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(EmployeeAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handleEmployeeAlreadyExistsException(EmployeeAlreadyExistsException exception) {
        String msg = exception.getMessage();
        ErrorResponse error = ErrorResponse.builder()
                .message(msg)
                .success(false)
                .status(HttpStatus.CONFLICT)
                .build();
        return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }
}
