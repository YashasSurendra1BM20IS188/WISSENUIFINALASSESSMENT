package com.example.backend.Exceptions;

public class EmptyEmployeesListException extends RuntimeException{
    public EmptyEmployeesListException() {
        super("There are no employee records");
    }

    public EmptyEmployeesListException(String msg) {
        super(msg);
    }
}
