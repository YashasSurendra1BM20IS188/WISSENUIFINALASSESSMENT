package com.example.backend.Controllers;

import com.example.backend.Exceptions.EmployeeAlreadyExistsException;
import com.example.backend.Exceptions.EmptyEmployeesListException;
import com.example.backend.Exceptions.NoEmployeeFoundException;
import com.example.backend.Models.Emp;
import com.example.backend.Payloads.EmployeeListResponse;
import com.example.backend.Payloads.EmployeeObjectResponse;
import com.example.backend.Services.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin("http://localhost:4200")
public class EmpRestController {

    private final EmployeeService empService;

    @GetMapping("/employees")
    public ResponseEntity<EmployeeListResponse> getAllEmployees() {
       List<Emp> empList = empService.retrieveAllEmployees();
       if(empList.isEmpty())
           throw new EmptyEmployeesListException();
       EmployeeListResponse response = EmployeeListResponse.builder()
               .message("Employee List")
               .success(true)
               .status(HttpStatus.OK)
               .employeeList(empList)
               .build();
       return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/employees/{id}")
    public ResponseEntity<EmployeeObjectResponse> getEmployeeById(@PathVariable int id) {
        if(!empService.employeeIdExists(id))
            throw new NoEmployeeFoundException("Employee Not found with given id: " + id);
        Emp empDetails = empService.getEmployeeDetails(id).orElse(null);
        EmployeeObjectResponse response = EmployeeObjectResponse.builder()
                .message("Employee Details with id: " + id)
                .success(true)
                .status(HttpStatus.OK)
                .employeeObject(empDetails)
                .build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/employees")
    public ResponseEntity<EmployeeObjectResponse> insertEmployee(@RequestBody Emp e) {
        if(empService.employeeIdExists(e.getEid()))
            throw new EmployeeAlreadyExistsException("Employee with id: " + e.getEid() + " already exists!");
        Emp newEmp = empService.saveEmployee(e);
        EmployeeObjectResponse response = EmployeeObjectResponse.builder()
                .message("Employee Created Successfully")
                .success(true)
                .status(HttpStatus.CREATED)
                .employeeObject(newEmp)
                .build();
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PutMapping("/employees")
    public ResponseEntity<EmployeeObjectResponse> update(@RequestBody Emp e) {
        if(!empService.employeeIdExists(e.getEid()))
            throw new NoEmployeeFoundException("Employee Not found with given id: " + e.getEid());
        Emp updatedEmp = empService.updateEmployeeDetails(e);
        EmployeeObjectResponse response = EmployeeObjectResponse.builder()
                .message("Employee Updated Successfully")
                .success(true)
                .status(HttpStatus.OK)
                .employeeObject(updatedEmp)
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<EmployeeObjectResponse> deleteEmployee(@PathVariable int id) {
        if(!empService.employeeIdExists(id))
            throw new NoEmployeeFoundException("Employee Not found with given id: " + id);
        Emp toDeleteEmp = empService.getEmployeeDetails(id).orElse(null);
        empService.deleteEmployeeRecord(id);
        EmployeeObjectResponse response = EmployeeObjectResponse.builder()
                .message("Employee Deleted Successfully")
                .success(true)
                .status(HttpStatus.OK)
                .employeeObject(toDeleteEmp)
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
