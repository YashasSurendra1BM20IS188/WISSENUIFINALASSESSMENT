package com.example.backend.Payloads;

import com.example.backend.Models.Emp;
import lombok.*;
import org.springframework.http.HttpStatus;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmployeeListResponse {
    private String message;
    private boolean success;
    private HttpStatus status;
    private List<Emp> employeeList;
}
