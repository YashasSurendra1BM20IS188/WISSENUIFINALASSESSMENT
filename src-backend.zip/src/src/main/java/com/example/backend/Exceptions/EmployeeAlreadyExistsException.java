package com.example.backend.Exceptions;

public class EmployeeAlreadyExistsException extends RuntimeException{
    public EmployeeAlreadyExistsException() {
        super("Employee already exists");
    }

    public EmployeeAlreadyExistsException(String msg) {
        super(msg);
    }
}
