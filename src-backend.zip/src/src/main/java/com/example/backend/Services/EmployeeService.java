package com.example.backend.Services;

import com.example.backend.Models.Emp;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    Emp saveEmployee(Emp emp);

    List<Emp> retrieveAllEmployees();

    Optional<Emp> getEmployeeDetails(int id);

    Emp updateEmployeeDetails(Emp emp);

    void deleteEmployeeRecord(int id);

    boolean employeeIdExists(int id);
}
