package com.example.backend.Exceptions;

public class NoEmployeeFoundException extends RuntimeException{

    public NoEmployeeFoundException() {
        super("Employee Not Found!");
    }

    public NoEmployeeFoundException(String msg) {
        super(msg);
    }
}
