package com.example.demo.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Account;

import com.example.demo.repositories.AccRepository;

@RestController
@CrossOrigin("http://localhost:4200")

public class AccRestController {
	@Autowired
	AccRepository repo;
	
	@GetMapping("/accounts/{id}")
	public Optional<Account> getAccountById(@PathVariable int id)
	{
		return repo.findById(id);
	}
	
	@PostMapping("/accounts")
	public Account insertAccount(@RequestBody Account a)
	{
		Account e;
		Optional<Account> opt= repo.findById(a.getAccountno());
		if (opt.isPresent()) {
			return null;
		}
		else
		{
			 e = opt.get();
			
		}
		
		return repo.save(e);
	}
	
	@PutMapping("/accounts/withdrawal")
	public Account withdrawal(@RequestParam int id, @RequestParam int  amount)
	{
		Account a;
		Optional<Account> opt= repo.findById(id);
		if (opt.isPresent()) {
			a = opt.get();
		}
		else
		{
			return null;
			 
			
		}
	
		if(a.getAmount()-amount>0)
		{
			a.setAmount(a.getAmount()-amount);
		}
		else
		{
			return null;
		}
			
		
		return repo.save(a);
	}
	@PutMapping("/accounts/deposit")
	public Account deposit(@RequestParam int id, @RequestParam int  amount)
	{
		
		Optional<Account> opt= repo.findById(id);
		Account a = opt.get();
		if (opt.isPresent()) {
			a = opt.get();
		}
		else
		{
			return null;
			 
			
		}
		
		a.setAmount(a.getAmount()+amount);	
		
		return repo.save(a);
	}
	@PutMapping("/accounts/chequedeposit")
	public Account chequedeposit(@RequestParam int id1, @RequestParam int  amount,@RequestParam int id2)
	{
		
		Optional<Account> opt= repo.findById(id1);
		Account a = opt.get();
		if (opt.isPresent()) {
			a = opt.get();
		}
		else
		{
			return null;
			 
			
		}
		Optional<Account> opt2= repo.findById(id2);
		Account a2 = opt.get();
		if (opt2.isPresent()) {
			a2 = opt.get();
		}
		else
		{
			return null;
			 
			
		}
		if(a.getAmount()-amount>0)
		{
			a.setAmount(a.getAmount()-amount);
		}
		else
		{
			return null;
		}
		a2.setAmount(a.getAmount()+amount);	
		
		return repo.save(a);
	}

//	@DeleteMapping("/accounts/{id}")
//	public void deleteEmployee(@PathVariable int id)
//	{
//		repo.deleteById(id);
//	}
	
	@GetMapping("/accounts")
	public List<Account> getEmployees()
	{
		return repo.findAll();
	}

	
}
